#include <gtest/gtest.h>
#include <gmock/gmock.h>  
#include "normalTest.h"
using ::testing::AtLeast;
using ::testing::Return;


//TEST(Suit_name, test_name) 
TEST(ServerTest, OneClientTesting) {
	//EXPECT_TRUE
	//EXPECT_CALL
	//EXPECT_EQ
}


TEST(ServerTest, TwoClientTesting) {

}

// first 'CounterTest' must a class name of inheried from testing::Test
//TEST_F(class_name, test_name)
TEST_F(CounterTest, IsEmptyInitially) {
	EXPECT_EQ(ct.Increment(), 2);
}

using ::testing::TestWithParam;

class  LeapYearCalendar
{
public:
	 LeapYearCalendar();
	~ LeapYearCalendar();
	bool isLeap(int v)
	{
		return true;
	}
	bool isOven(int v)
	{
		return v%2==0;
	}

private:

};

 LeapYearCalendar:: LeapYearCalendar()
{
}

 LeapYearCalendar::~ LeapYearCalendar()
{
}

TEST(LeapYearIterationTest, OddYearsAreNotLeapYears) {
	LeapYearCalendar leapYearCalendar;
	auto oddYears = std::vector<int>{ 1, 3, 711, 2013 };
	for (auto oddYear : oddYears) {
		ASSERT_FALSE(leapYearCalendar.isLeap(oddYear));
	}
}



//TEST_P(class_name, test_name)

class MyTestSuite : public testing::TestWithParam<int> 
{
public:
	MyTestSuite() {}
	~MyTestSuite() {}
	bool isLeap(int v)
	{
		return true;
	}
	LeapYearCalendar ltc;
};

TEST_P(MyTestSuite, MyTest)
{
	std::cout << "Example Test Param: " << GetParam() << std::endl;

	EXPECT_TRUE(ltc.isOven(GetParam()));
	EXPECT_TRUE(ltc.isLeap(GetParam()));
}

INSTANTIATE_TEST_SUITE_P(MyGroup, MyTestSuite, testing::Range(0, 10),
	testing::PrintToStringParamName());


template<typename T>
auto addOne(T t) {
	return t + 1;
}

struct AddOneTestsFixture
	: public testing::TestWithParam<std::tuple<int, int>> {};

TEST_P(AddOneTestsFixture, doAdd) {
	int input = std::get<0>(GetParam());
	int expect = std::get<1>(GetParam());
	ASSERT_EQ(addOne(input), expect)
		<< "addOne(" << input << ") != " << expect << "!";
}


INSTANTIATE_TEST_SUITE_P(
	AddOneTests,
	AddOneTestsFixture,
	testing::Values(
		std::make_tuple(1, 2),
		std::make_tuple(3, 4),
		std::make_tuple(9, 10)));


// The main test class for the USB hidl HAL
class UsbHidlTest : public testing::TestWithParam<std::string> {

	virtual void SetUp() override {
		GetParam();		
	}
};

//TYPED_TEST() instead of TEST_F() 
// if use Typed Tests

// FRIEND_TEST(TestSuiteName, TestName);
// foo.h
class Foo {	
private:
	FRIEND_TEST(FooTest, BarReturnsZeroOnNull);

	int Bar(void* x);
};

// foo_test.cc

TEST(FooTest, BarReturnsZeroOnNull) {
	Foo foo;
	EXPECT_EQ(foo.Bar(NULL), 0);  // Uses Foo's private member Bar().
}
