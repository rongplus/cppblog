#pragma once

#include <gtest/gtest.h>
#include "../MyUnitMath/Counter.h"



class CounterTest : public testing::Test {
protected:
	void SetUp() override {
		// q0_ remains empty
		ct.Increment();
	}

	// void TearDown() override {}

	Counter ct;
};
#ifdef ABC
TEST_F(CounterTest, IsEmptyInitially) {
	EXPECT_EQ(ct.Increment(), 2);
}

TEST_F(CounterTest, DequeueWorks) {
	int n = ct.Increment();
	EXPECT_EQ(n, 1);

	n = ct.Increment();
	EXPECT_EQ(n, 2);

	n = ct.Increment();
	EXPECT_EQ(n, 2);

}
#endif // ABC