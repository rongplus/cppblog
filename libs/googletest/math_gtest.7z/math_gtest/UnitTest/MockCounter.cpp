#include "MockCounter.h"



class MockCounter : public Counter
{
public:
	MOCK_METHOD(void, Increase10, (), (override));
	MOCK_METHOD(int, current, (), (override));
};

using ::testing::AtLeast;    
using ::testing::Return;
// #1

TEST(CounterTest, EXPECT_CALL_test)
{
	MockCounter turtle;                             // #2	
	//MockCounter ct;                  // #3
	

	EXPECT_TRUE(turtle.testCall( ));      // #4
	EXPECT_CALL(turtle, Increase10())                  // #5
		.Times(AtLeast(1));
	turtle.testCall();
}

TEST(CounterTest, Return_test)
{
	MockCounter mc;                             // #2	
	

	EXPECT_TRUE(mc.testCall());      // #4
	EXPECT_CALL(mc, current())                  // #5
		.Times(5)
		.WillOnce(Return(100))
		.WillOnce(Return(150))
		.WillRepeatedly(Return(200));
	mc.testCall();
	EXPECT_EQ(100, mc.current());
	EXPECT_EQ(150, mc.current());
	EXPECT_EQ(200, mc.current());
	EXPECT_EQ(100, mc.current());
	EXPECT_EQ(200, mc.current());
}

//#define  TURTLE_ 1



class Painter {
public:
	Painter(Turtle* t) :tt(t) {}

	bool DrawCircle(int x, int y, int z)
	{
		tt->PenDown();
		return true;
	}

	bool Draw(int x, int y, int z)
	{
		return true;
	}

	Turtle* tt;
};

class MockTurtle : public Turtle {
public:

	MOCK_METHOD(void, PenUp, (), (override));
	MOCK_METHOD(void, PenDown, (), (override));
	MOCK_METHOD(void, Forward, (int distance), (override));
	MOCK_METHOD(void, Turn, (int degrees), (override));
	MOCK_METHOD(void, GoTo, (int x, int y), (override));
	MOCK_METHOD(int, GetX, (), (const, override));
	MOCK_METHOD(int, GetY, (), (const, override));
};
#ifdef  TURTLE_
TEST(MyTurtle, CanTurtle) {
	MockTurtle turtle;                              // #2
	EXPECT_CALL(turtle, PenDown())                  // #3
		.Times(AtLeast(1));

	Painter painter(&turtle);                       // #4

	EXPECT_TRUE(painter.DrawCircle(0, 0, 10));      // #5
}


TEST(MyTurtle, Turtle) {
	MockTurtle turtle;                              // #2
	EXPECT_CALL(turtle, PenDown())                  // #3
		.Times(AtLeast(1));

	Painter painter(&turtle);                       // #4

	EXPECT_TRUE(painter.Draw(0, 0, 10));      // #5
}
#endif //  TURTLE_
/*
EXPECT_CALL(mock_object, method(matchers))
	.Times(cardinality)
	.WillOnce(action)
	.WillRepeatedly(action);

	EXPECT_CALL(turtle, GetX())
	.Times(5)
	.WillOnce(Return(100))
	.WillOnce(Return(150))
	.WillRepeatedly(Return(200));


	EXPECT_CALL(turtle, Forward(100));


	using ::testing::Return;
...
int n = 100;
EXPECT_CALL(turtle, GetX())
	.Times(4)
	.WillRepeatedly(Return(n++));

	*/
